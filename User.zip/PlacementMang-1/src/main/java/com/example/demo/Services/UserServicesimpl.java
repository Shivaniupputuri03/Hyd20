package com.example.demo.Services;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.User;
import com.example.demo.Repositary.UserRepositary;

@Service
public class UserServicesimpl implements UserServices{
	
	@Autowired
	UserRepositary ur;
	
	public User saveUser(User user ) {
		return ur.save(user);
		
		}

		public List<User> fetchUserList() {
			// TODO Auto-generated method stub
			return ur.findAll();
		}

		public User fetchUserById(Long id) {
			// TODO Auto-generated method stub
			return ur.findById(id).get();
		}

		public void deleteUserById(Long id) {
			// TODO Auto-generated method stub
		    ur.deleteById(id);
		}

		public User updateUser(Long id, User user) {
			// TODO Auto-generated method stub
			 User userDB = ur.findById(id).get();
			 
				       if(Objects.nonNull(user.getName()) &&
				               !"".equalsIgnoreCase(user.getName())) {
				           userDB.setName(user.getName());
				       }
                       
				       if(Objects.nonNull(user.getType()) &&
				               !"".equalsIgnoreCase(user.getType())) {
				           userDB.setPassword(user.getType());
				       }

				       if(Objects.nonNull(user.getPassword()) &&
				               !"".equalsIgnoreCase(user.getPassword())) {
				           userDB.setPassword(user.getPassword());
				       }

				       return ur.save(userDB);
		}

}
