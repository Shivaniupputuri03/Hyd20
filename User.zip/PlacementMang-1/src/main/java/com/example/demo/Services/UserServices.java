package com.example.demo.Services;

import java.util.List;

import com.example.demo.Entity.User;

public interface UserServices {

	User saveUser(User user);

	List<User> fetchUserList();

	User fetchUserById(Long id);

	void deleteUserById(Long id);

	User updateUser(Long id, User user);

}
